package com.letrasvivas.book_api.service;

import com.letrasvivas.book_api.model.Book;
import com.letrasvivas.book_api.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    private final BookRepository bookRepository;

    @Autowired
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public List<Book> findAllBooks() {
        return bookRepository.findAll();
    }

    public Optional<Book> findBookById(Long id) {
        return bookRepository.findById(id);
    }

    public Book saveBook(Book book) {
        return bookRepository.save(book);
    }

    public void deleteBook(Long id) {
        // Mejorado: Comprobar si el libro existe antes de eliminarlo
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
        } else {
            // Se puede lanzar una excepción personalizada aquí,
            // que luego será capturada por el GlobalExceptionHandler.
            throw new RuntimeException("Book with id " + id + " not found.");
        }
    }

    public List<Book> findBooksByTitle(String title) {
        return bookRepository.findByTitleContainingIgnoreCase(title);
    }
}